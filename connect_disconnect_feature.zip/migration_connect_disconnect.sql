-- Migration: farmer connect/disconnect (center-initiated, farmer-accepted,
-- farmer-only disconnect). Run once in Supabase SQL Editor.

create type farmer_status as enum ('pending', 'active', 'disconnected');

alter table farmers add column if not exists status farmer_status not null default 'active';

-- A mobile can be pending/active at only ONE farmers row (one center)
-- system-wide. Multiple 'disconnected' rows for the same mobile are fine —
-- that's how history at previous centers stays intact.
create unique index if not exists idx_farmers_mobile_active_unique
  on farmers (mobile)
  where status in ('pending', 'active') and mobile is not null;

-- BUGFIX: farmers previously had a SELECT policy only — no insert/update
-- policy existed at all, so every farmer added by a center was silently
-- failing to sync to Supabase (RLS defaults to deny with no matching policy).
create policy farmers_insert on farmers for insert with check (
  (select role from users where id = auth.uid()) = 'super_admin'
  or is_descendant_of(center_id, (select center_id from users where id = auth.uid()))
);
create policy farmers_update on farmers for update using (
  (select role from users where id = auth.uid()) = 'super_admin'
  or is_descendant_of(center_id, (select center_id from users where id = auth.uid()))
) with check (
  (select role from users where id = auth.uid()) = 'super_admin'
  or is_descendant_of(center_id, (select center_id from users where id = auth.uid()))
);

-- Whenever a mobile is newly set or changed on a farmer row, the connection
-- resets to 'pending' — the farmer must explicitly accept before it's
-- considered live (the center can still record collections against them
-- either way; this only gates the farmer's own visibility/acceptance).
create or replace function farmers_reset_status_on_mobile_change()
returns trigger language plpgsql as $$
begin
  if new.mobile is not null and (TG_OP = 'INSERT' or new.mobile is distinct from old.mobile) then
    new.status := 'pending';
  end if;
  return new;
end;
$$;

drop trigger if exists trg_farmers_reset_status on farmers;
create trigger trg_farmers_reset_status
before insert or update of mobile on farmers
for each row execute function farmers_reset_status_on_mobile_change();

-- Extend verify_user_pin to also return farmer connection info, so the app
-- knows whether to show the pending-accept screen or the full dashboard.
create or replace function verify_user_pin(p_mobile text, p_pin text)
returns table(
  id uuid, role user_role, center_id uuid, must_change_pin boolean,
  farmer_id uuid, farmer_status farmer_status, farmer_center_name text
)
language sql security definer as $$
  select
    u.id, u.role, u.center_id, u.must_change_pin,
    f.id as farmer_id, f.status as farmer_status, c.name as farmer_center_name
  from users u
  left join farmers f on f.id = u.farmer_id
  left join centers c on c.id = f.center_id
  where u.mobile = p_mobile and u.pin_hash = crypt(p_pin, u.pin_hash) and u.is_active = true;
$$;

-- Farmer accepts or rejects the pending connection at their current center.
-- Reject immediately frees the mobile for another center (status just goes
-- straight to 'disconnected' — same end-state as a later voluntary leave).
create or replace function respond_to_farmer_connection(p_farmer_id uuid, p_accept boolean)
returns void language plpgsql security definer as $$
begin
  update farmers
  set status = case when p_accept then 'active' else 'disconnected' end,
      updated_at = now()
  where id = p_farmer_id and status = 'pending';
end;
$$;

-- Farmer-initiated disconnect — only allowed once their balance is cleared.
create or replace function disconnect_farmer(p_farmer_id uuid)
returns table(ok boolean, message text) language plpgsql security definer as $$
declare
  v_balance numeric;
begin
  select balance into v_balance from farmer_ledger_view where farmer_id = p_farmer_id;
  if v_balance is null then v_balance := 0; end if;

  if v_balance <> 0 then
    return query select false, ('बाँकी रकम रु. ' || v_balance || ' — पहिले भुक्तानी बुझाउनुहोस्।')::text;
    return;
  end if;

  update farmers set status = 'disconnected', updated_at = now()
  where id = p_farmer_id and status = 'active';

  return query select true, 'सफलतापूर्वक विच्छेद गरियो'::text;
end;
$$;
