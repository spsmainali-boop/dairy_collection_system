// Supabase Edge Function: respond-connection
// A farmer accepts or rejects a pending connection to a center. Verifies
// mobile+PIN server-side (same pattern as verify-pin), so only the actual
// farmer can respond to their own connection.
// Deploy: supabase functions deploy respond-connection

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { mobile, pin, accept } = await req.json();
    if (!mobile || !pin || typeof accept !== 'boolean') {
      return new Response(JSON.stringify({ error: 'mobile, pin, and accept (boolean) required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const supabase = createClient(supabaseUrl, serviceRoleKey);
    const { data, error } = await supabase.rpc('verify_user_pin', { p_mobile: mobile, p_pin: pin });

    if (error || !data || data.length === 0) {
      return new Response(JSON.stringify({ error: 'invalid credentials' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const user = data[0];
    if (user.role !== 'farmer' || !user.farmer_id || user.farmer_status !== 'pending') {
      return new Response(JSON.stringify({ error: 'no pending connection to respond to' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    await supabase.rpc('respond_to_farmer_connection', { p_farmer_id: user.farmer_id, p_accept: accept });

    return new Response(
      JSON.stringify({ ok: true, status: accept ? 'active' : 'disconnected' }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
