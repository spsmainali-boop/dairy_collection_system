// Supabase Edge Function: disconnect-farmer
// A farmer voluntarily disconnects from their current center. Only the
// farmer can do this (verified via mobile+PIN), and only if their balance
// is fully cleared. Deploy: supabase functions deploy disconnect-farmer

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { mobile, pin } = await req.json();
    if (!mobile || !pin) {
      return new Response(JSON.stringify({ error: 'mobile and pin required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const supabase = createClient(supabaseUrl, serviceRoleKey);
    const { data, error } = await supabase.rpc('verify_user_pin', { p_mobile: mobile, p_pin: pin });

    if (error || !data || data.length === 0) {
      return new Response(JSON.stringify({ error: 'invalid credentials' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const user = data[0];
    if (user.role !== 'farmer' || !user.farmer_id || user.farmer_status !== 'active') {
      return new Response(JSON.stringify({ error: 'no active connection to disconnect' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { data: result, error: rpcError } = await supabase.rpc('disconnect_farmer', { p_farmer_id: user.farmer_id });
    if (rpcError) {
      return new Response(JSON.stringify({ error: rpcError.message }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const row = result[0];
    return new Response(JSON.stringify({ ok: row.ok, message: row.message }), {
      status: row.ok ? 200 : 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
